# Проект movies-explorer

Проект содержит Front-end и back-end части

Back-end часть служит для сохранения фильмов и данных пользователя

Front-end часть отвечает за поиск фильмов(база фильмов содержится на сервисе 'https://api.nomoreparties.co/beatfilm-movies')
 для последующего сохранения(кнопка лайк) на back-end и работы с уже сохраненными фильмами

Ссылки:
Front-end:https://xenoxil.movies-explorer.nomoreparties.sbs/login - страница логина
https://xenoxil.movies-explorer.nomoreparties.sbs/signup - страница регистрации пользователя
https://xenoxil.movies-explorer.nomoreparties.sbs/movies - страница поиска фильмов beatfilm-movies
https://xenoxil.movies-explorer.nomoreparties.sbs/movies - страница поиска по сохраненным фильма пользователя
https://xenoxil.movies-explorer.nomoreparties.sbs/landing - страница с информацией о проекте и разработчике
https://xenoxil.movies-explorer.nomoreparties.sbs/profile - страница с данными о профайле пользователя

Pull-request https://github.com/xenoxil/movies-explorer-frontend/pull/3#issuecomment-1205569861


